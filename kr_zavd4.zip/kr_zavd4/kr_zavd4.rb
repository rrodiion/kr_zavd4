def generate_abbreviations(word_list)
  word_list.each do |word|
    # Розділити слово на окремі частини, використовуючи пробіли як роздільник
    parts = word.split
    abbreviation = ""

    # Для кожної частини взяти першу літеру та перетворити її в велику букву
    parts.each do |part|
      abbreviation += part[0].upcase
    end

    puts abbreviation
  end
end

# Приклад використання програми
word_list = ["центральний обробник одиниць", "світова організація охорони здоров'я", "програмування на Ruby"]
generate_abbreviations(word_list)
